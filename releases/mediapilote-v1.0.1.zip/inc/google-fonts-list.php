<?php
// Liste simplifiée de Google Fonts (nom => variantes)
return [
    'Roboto' => ['400', '400italic', '700', '700italic'],
    'Open Sans' => ['400', '400italic', '700', '700italic'],
    'Lato' => ['400', '400italic', '700', '700italic'],
    'Montserrat' => ['400', '700'],
    'Oswald' => ['400', '700'],
    'Poppins' => ['400', '700'],
    'Source Sans Pro' => ['400', '700'],
    'Nunito' => ['400', '700'],
    'Merriweather' => ['400', '700'],
    'Raleway' => ['400', '700'],
];
