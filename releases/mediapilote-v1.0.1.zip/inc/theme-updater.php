<?php
/**
 * Classe de gestion des mises à jour automatiques du thème
 * 
 * @author Emmanuel Claude / Mediapilote
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class MediapiloteThemeUpdater {
    
    private $theme_slug;
    private $version;
    private $update_path;
    private $license_key;
    
    public function __construct($theme_slug, $version, $update_path, $license_key) {
        $this->theme_slug = $theme_slug;
        $this->version = $version;
        $this->update_path = $update_path;
        $this->license_key = $license_key;
        
        add_filter('pre_set_site_transient_update_themes', [$this, 'check_for_update']);
        add_filter('themes_api', [$this, 'theme_api_call'], 10, 3);
    }
    
    /**
     * Vérifier les mises à jour disponibles
     */
    public function check_for_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }
        
        // Obtenir la version installée
        $theme_data = wp_get_theme($this->theme_slug);
        $current_version = $theme_data->get('Version');
        
        // Vérifier s'il y a une mise à jour
        $remote_version = $this->get_remote_version();
        
        if (version_compare($current_version, $remote_version, '<')) {
            $transient->response[$this->theme_slug] = [
                'theme' => $this->theme_slug,
                'new_version' => $remote_version,
                'url' => $this->update_path,
                'package' => $this->get_download_url()
            ];
        }
        
        return $transient;
    }
    
    /**
     * Obtenir la version distante
     */
    private function get_remote_version() {
        $request = wp_remote_get($this->update_path . 'update-server.php?' . http_build_query([
            'action' => 'get_version',
            'slug' => $this->theme_slug,
            'version' => $this->version,
            'license_key' => $this->license_key
        ]));
        
        if (!is_wp_error($request) && wp_remote_retrieve_response_code($request) === 200) {
            $body = wp_remote_retrieve_body($request);
            $data = json_decode($body, true);
            
            if (isset($data['new_version'])) {
                return $data['new_version'];
            }
        }
        
        return false;
    }
    
    /**
     * Obtenir l'URL de téléchargement
     */
    private function get_download_url() {
        $token = hash('sha256', $this->license_key . date('Y-m-d-H'));
        
        return $this->update_path . 'download.php?' . http_build_query([
            'slug' => $this->theme_slug,
            'license_key' => $this->license_key,
            'token' => $token
        ]);
    }
    
    /**
     * API des thèmes pour afficher les informations de mise à jour
     */
    public function theme_api_call($result, $action, $args) {
        if ($action !== 'theme_information' || $args->slug !== $this->theme_slug) {
            return $result;
        }
        
        $request = wp_remote_get($this->update_path . 'update-server.php?' . http_build_query([
            'action' => 'get_info',
            'slug' => $this->theme_slug,
            'license_key' => $this->license_key
        ]));
        
        if (!is_wp_error($request) && wp_remote_retrieve_response_code($request) === 200) {
            $body = wp_remote_retrieve_body($request);
            $data = json_decode($body, true);
            
            if ($data) {
                return (object) $data;
            }
        }
        
        return $result;
    }
    
    /**
     * Vérification manuelle des mises à jour (pour les administrateurs)
     */
    public function force_check_update() {
        delete_site_transient('update_themes');
        wp_update_themes();
    }
}

/**
 * Initialiser le système de mise à jour
 */
function init_mediapilote_theme_updater() {
    // Configuration du thème
    $config = [
        'theme_slug' => get_template(), // Nom du dossier du thème
        'version' => wp_get_theme()->get('Version'), // Version actuelle
        'update_path' => 'https://mediapilote-laval.fr/theme-updates/', // URL de votre serveur
        'license_key' => get_option('mediapilote_license_key', 'mp_aiko_theme_2024_' . md5('mediapilote')) // Clé de licence
    ];
    
    new MediapiloteThemeUpdater(
        $config['theme_slug'],
        $config['version'],
        $config['update_path'],
        $config['license_key']
    );
}

// Initialiser uniquement si c'est notre thème
if (get_template() === 'mediapilote') {
    add_action('init', 'init_mediapilote_theme_updater');
}

/**
 * Ajouter une page d'administration pour gérer les mises à jour
 */
function mediapilote_updater_admin_menu() {
    add_theme_page(
        'Mises à jour du thème',
        'Mises à jour',
        'manage_options',
        'mediapilote-updates',
        'mediapilote_updater_admin_page'
    );
}
add_action('admin_menu', 'mediapilote_updater_admin_menu');

/**
 * Page d'administration des mises à jour
 */
function mediapilote_updater_admin_page() {
    if (isset($_POST['check_updates'])) {
        delete_site_transient('update_themes');
        wp_update_themes();
        echo '<div class="notice notice-success"><p>Vérification des mises à jour effectuée.</p></div>';
    }
    
    if (isset($_POST['save_license'])) {
        update_option('mediapilote_license_key', sanitize_text_field($_POST['license_key']));
        echo '<div class="notice notice-success"><p>Clé de licence sauvegardée.</p></div>';
    }
    
    $license_key = get_option('mediapilote_license_key', '');
    $theme = wp_get_theme();
    
    ?>
    <div class="wrap">
        <h1>Mises à jour du thème Aiko</h1>
        
        <div class="card">
            <h2>Informations du thème</h2>
            <p><strong>Nom :</strong> <?php echo esc_html($theme->get('Name')); ?></p>
            <p><strong>Version actuelle :</strong> <?php echo esc_html($theme->get('Version')); ?></p>
            <p><strong>Auteur :</strong> <?php echo esc_html($theme->get('Author')); ?></p>
        </div>
        
        <div class="card">
            <h2>Configuration de la licence</h2>
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th scope="row">Clé de licence</th>
                        <td>
                            <input type="text" name="license_key" value="<?php echo esc_attr($license_key); ?>" class="regular-text" />
                            <p class="description">Entrez votre clé de licence pour recevoir les mises à jour automatiques.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Sauvegarder', 'primary', 'save_license'); ?>
            </form>
        </div>
        
        <div class="card">
            <h2>Vérification manuelle</h2>
            <p>Cliquez sur le bouton ci-dessous pour forcer la vérification des mises à jour.</p>
            <form method="post">
                <?php submit_button('Vérifier les mises à jour', 'secondary', 'check_updates'); ?>
            </form>
        </div>
    </div>
    <?php
}
?>