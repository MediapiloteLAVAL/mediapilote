<?php
/**
 * Configuration du système de mise à jour du thème Aiko by Mediapilote
 * 
 * @author Emmanuel Claude / Mediapilote
 * @version 1.0.0
 */

return [
    // Informations du thème
    'theme_name' => 'Aiko by Mediapilote',
    'theme_slug' => 'mediapilote',
    'current_version' => '1.0.0',
    
    // Configuration du serveur de mise à jour
    'update_server' => [
        'url' => 'https://aiko.mediapilote-laval.fr/', // Remplacez par votre domaine
        'timeout' => 30,
        'ssl_verify' => true
    ],
    
    // Sécurité
    'license_key' => 'mp_aiko_theme_2024_' . md5('mediapilote'), // Clé unique sécurisée
    'update_check_interval' => 12 * 3600, // Vérifier toutes les 12h (12 * 3600 secondes)
    
    // Notifications
    'notify_on_update' => true,
    'admin_email_notification' => true,
    
    // Maintenance
    'backup_before_update' => true,
    'max_backup_files' => 3,
    
    // Développement
    'debug_mode' => defined('WP_DEBUG') ? WP_DEBUG : false,
    'log_updates' => true
];
?>