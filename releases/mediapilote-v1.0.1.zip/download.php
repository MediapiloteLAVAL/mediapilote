<?php
/**
 * Script de téléchargement sécurisé pour les mises à jour du thème
 * 
 * @author Emmanuel Claude / Mediapilote
 */

// Configuration (identique au serveur principal)
define('THEME_SLUG', 'mediapilote');
define('UPDATE_KEY', 'mp_aiko_theme_2024_' . md5('mediapilote'));
define('THEME_VERSION', '1.0.1');

// Chemin vers le fichier ZIP du thème
define('THEME_ZIP_PATH', __DIR__ . '/releases/mediapilote-v' . THEME_VERSION . '.zip');

/**
 * Vérifier l'autorisation de téléchargement
 */
function verify_download_request() {
    $slug = $_REQUEST['slug'] ?? '';
    $license_key = $_REQUEST['license_key'] ?? '';
    $token = $_REQUEST['token'] ?? '';
    
    if ($slug !== THEME_SLUG || $license_key !== UPDATE_KEY) {
        return false;
    }
    
    // Vérification du token temporaire (optionnel, pour plus de sécurité)
    $expected_token = hash('sha256', $license_key . date('Y-m-d-H'));
    return $token === $expected_token;
}

/**
 * Générer le token de téléchargement
 */
function generate_download_token($license_key) {
    return hash('sha256', $license_key . date('Y-m-d-H'));
}

// Traitement de la requête
if (!verify_download_request()) {
    http_response_code(403);
    die('Accès refusé');
}

// Vérifier que le fichier existe
if (!file_exists(THEME_ZIP_PATH)) {
    http_response_code(404);
    die('Fichier de mise à jour introuvable');
}

// Préparer le téléchargement
$filename = basename(THEME_ZIP_PATH);
$filesize = filesize(THEME_ZIP_PATH);

// Headers pour le téléchargement
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . $filesize);
header('Cache-Control: no-cache, must-revalidate');
header('Expires: 0');

// Envoyer le fichier
readfile(THEME_ZIP_PATH);
exit;
?>