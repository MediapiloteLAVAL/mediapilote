<?php
/**
 * Serveur de mises à jour pour le thème Aiko by Mediapilote
 * 
 * Ce script gère les vérifications et téléchargements de mises à jour
 * pour les installations distantes du thème.
 * 
 * @author Emmanuel Claude / Mediapilote
 * @version 1.0.0
 */

// Configuration du serveur
define('THEME_SLUG', 'mediapilote');
define('THEME_NAME', 'Aiko by Mediapilote');
define('CURRENT_VERSION', '1.0.1'); // Version actuelle du thème
define('UPDATE_PATH', 'https://mediapilote-laval.fr/theme-updates/'); // URL de votre serveur
define('DOWNLOAD_URL', UPDATE_PATH . 'download.php');

// Clé de sécurité (à changer)
define('UPDATE_KEY', 'mp_aiko_theme_2024_' . md5('mediapilote'));

// Headers pour API REST
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

/**
 * Vérifier la validité de la requête
 */
function verify_request() {
    $theme_slug = $_REQUEST['slug'] ?? '';
    $license_key = $_REQUEST['license_key'] ?? '';
    
    // Vérification de base
    if ($theme_slug !== THEME_SLUG) {
        return false;
    }
    
    // Vous pouvez ajouter ici une vérification de licence plus sophistiquée
    // Pour l'instant, on utilise une clé simple
    return $license_key === UPDATE_KEY;
}

/**
 * Obtenir les informations de version
 */
function get_version_info() {
    return [
        'version' => CURRENT_VERSION,
        'download_url' => DOWNLOAD_URL,
        'details_url' => UPDATE_PATH . 'details.php',
        'sections' => [
            'description' => 'Thème Aiko by Mediapilote - Version mise à jour',
            'changelog' => get_changelog()
        ]
    ];
}

/**
 * Changelog des versions
 */
function get_changelog() {
    return '
    <h4>Version 1.0.1</h4>
    <ul>
        <li>Correction de bugs mineurs</li>
        <li>Amélioration des performances</li>
        <li>Mise à jour des dépendances</li>
    </ul>
    
    <h4>Version 1.0.0</h4>
    <ul>
        <li>Version initiale du thème</li>
    </ul>';
}

/**
 * Traiter les requêtes
 */
$action = $_REQUEST['action'] ?? '';

switch ($action) {
    case 'get_version':
        if (!verify_request()) {
            http_response_code(401);
            echo json_encode(['error' => 'Requête non autorisée']);
            exit;
        }
        
        $current_version = $_REQUEST['version'] ?? '0.0.0';
        
        if (version_compare($current_version, CURRENT_VERSION, '<')) {
            echo json_encode([
                'update_available' => true,
                'new_version' => CURRENT_VERSION,
                'current_version' => $current_version,
                'update_info' => get_version_info()
            ]);
        } else {
            echo json_encode([
                'update_available' => false,
                'current_version' => $current_version
            ]);
        }
        break;
        
    case 'get_info':
        if (!verify_request()) {
            http_response_code(401);
            echo json_encode(['error' => 'Requête non autorisée']);
            exit;
        }
        
        echo json_encode(get_version_info());
        break;
        
    default:
        http_response_code(400);
        echo json_encode(['error' => 'Action non valide']);
        break;
}

exit;
?>