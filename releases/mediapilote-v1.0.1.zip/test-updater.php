<?php
/**
 * Script de test pour le système de mise à jour du thème
 * 
 * Ce script peut être utilisé pour tester la communication
 * entre le client et le serveur de mise à jour
 * 
 * @author Emmanuel Claude / Mediapilote
 */

// Configuration de test
$test_config = [
    'server_url' => 'https://votre-serveur.com/theme-updates/update-server.php',
    'theme_slug' => 'mediapilote',
    'license_key' => 'votre_cle_secrete_unique_2024',
    'current_version' => '1.0.0'
];

/**
 * Tester la vérification de version
 */
function test_version_check($config) {
    echo "=== Test de vérification de version ===\n";
    
    $url = $config['server_url'] . '?' . http_build_query([
        'action' => 'get_version',
        'slug' => $config['theme_slug'],
        'version' => $config['current_version'],
        'license_key' => $config['license_key']
    ]);
    
    echo "URL testée: $url\n";
    
    $response = file_get_contents($url, false, stream_context_create([
        'http' => [
            'timeout' => 30,
            'user_agent' => 'Mediapilote Theme Updater Test/1.0'
        ]
    ]));
    
    if ($response === false) {
        echo "❌ Erreur: Impossible de contacter le serveur\n";
        return false;
    }
    
    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo "❌ Erreur: Réponse JSON invalide\n";
        echo "Réponse brute: $response\n";
        return false;
    }
    
    echo "✅ Réponse du serveur:\n";
    echo json_encode($data, JSON_PRETTY_PRINT) . "\n";
    
    return $data;
}

/**
 * Tester la récupération des informations
 */
function test_info_retrieval($config) {
    echo "\n=== Test de récupération d'informations ===\n";
    
    $url = $config['server_url'] . '?' . http_build_query([
        'action' => 'get_info',
        'slug' => $config['theme_slug'],
        'license_key' => $config['license_key']
    ]);
    
    echo "URL testée: $url\n";
    
    $response = file_get_contents($url, false, stream_context_create([
        'http' => [
            'timeout' => 30,
            'user_agent' => 'Mediapilote Theme Updater Test/1.0'
        ]
    ]));
    
    if ($response === false) {
        echo "❌ Erreur: Impossible de contacter le serveur\n";
        return false;
    }
    
    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo "❌ Erreur: Réponse JSON invalide\n";
        echo "Réponse brute: $response\n";
        return false;
    }
    
    echo "✅ Informations du thème:\n";
    echo json_encode($data, JSON_PRETTY_PRINT) . "\n";
    
    return $data;
}

/**
 * Tester l'accès au téléchargement
 */
function test_download_access($config, $download_url = null) {
    echo "\n=== Test d'accès au téléchargement ===\n";
    
    if (!$download_url) {
        $download_url = str_replace('update-server.php', 'download.php', $config['server_url']);
    }
    
    $token = hash('sha256', $config['license_key'] . date('Y-m-d-H'));
    $url = $download_url . '?' . http_build_query([
        'slug' => $config['theme_slug'],
        'license_key' => $config['license_key'],
        'token' => $token
    ]);
    
    echo "URL de téléchargement: $url\n";
    
    // Test avec une requête HEAD pour vérifier l'accès sans télécharger
    $context = stream_context_create([
        'http' => [
            'method' => 'HEAD',
            'timeout' => 30,
            'user_agent' => 'Mediapilote Theme Updater Test/1.0'
        ]
    ]);
    
    $headers = get_headers($url, 1, $context);
    
    if ($headers === false) {
        echo "❌ Erreur: Impossible de contacter le serveur de téléchargement\n";
        return false;
    }
    
    $status_code = null;
    if (isset($headers[0])) {
        preg_match('/HTTP\/\d\.\d\s+(\d+)/', $headers[0], $matches);
        $status_code = isset($matches[1]) ? (int)$matches[1] : null;
    }
    
    echo "Code de statut HTTP: $status_code\n";
    
    if ($status_code === 200) {
        echo "✅ Accès au téléchargement autorisé\n";
        if (isset($headers['Content-Type'])) {
            echo "Type de contenu: " . $headers['Content-Type'] . "\n";
        }
        if (isset($headers['Content-Length'])) {
            echo "Taille du fichier: " . $headers['Content-Length'] . " octets\n";
        }
        return true;
    } elseif ($status_code === 403) {
        echo "❌ Accès refusé (vérifiez la clé de licence et le token)\n";
    } elseif ($status_code === 404) {
        echo "❌ Fichier de mise à jour non trouvé\n";
    } else {
        echo "❌ Erreur HTTP: $status_code\n";
    }
    
    return false;
}

/**
 * Afficher le résumé des tests
 */
function show_test_summary($results) {
    echo "\n" . str_repeat("=", 50) . "\n";
    echo "RÉSUMÉ DES TESTS\n";
    echo str_repeat("=", 50) . "\n";
    
    $total_tests = count($results);
    $passed_tests = count(array_filter($results));
    
    echo "Tests réussis: $passed_tests/$total_tests\n";
    
    foreach ($results as $test_name => $result) {
        $status = $result ? "✅ RÉUSSI" : "❌ ÉCHOUÉ";
        echo "- $test_name: $status\n";
    }
    
    if ($passed_tests === $total_tests) {
        echo "\n🎉 Tous les tests sont passés ! Le système de mise à jour fonctionne correctement.\n";
    } else {
        echo "\n⚠️  Certains tests ont échoué. Vérifiez la configuration.\n";
    }
}

/**
 * Instructions pour la configuration
 */
function show_configuration_help() {
    echo "\n" . str_repeat("=", 50) . "\n";
    echo "AIDE À LA CONFIGURATION\n";
    echo str_repeat("=", 50) . "\n";
    echo "Si les tests échouent, vérifiez :\n\n";
    echo "1. URL du serveur dans \$test_config['server_url']\n";
    echo "2. Clé de licence dans \$test_config['license_key']\n";
    echo "3. Que les fichiers update-server.php et download.php sont uploadés\n";
    echo "4. Que le dossier 'releases/' existe et est accessible en écriture\n";
    echo "5. Que la même clé de licence est configurée partout\n\n";
    echo "Pour modifier la configuration de test, éditez ce fichier.\n";
}

// === EXÉCUTION DES TESTS ===

echo "🧪 Test du système de mise à jour du thème Aiko by Mediapilote\n";
echo "================================================================\n\n";

// Afficher la configuration
echo "Configuration de test:\n";
foreach ($test_config as $key => $value) {
    if ($key === 'license_key') {
        $display_value = str_repeat('*', strlen($value) - 4) . substr($value, -4);
    } else {
        $display_value = $value;
    }
    echo "- $key: $display_value\n";
}

// Exécuter les tests
$results = [
    'Vérification de version' => false,
    'Récupération d\'informations' => false,
    'Accès au téléchargement' => false
];

// Test 1: Vérification de version
$version_data = test_version_check($test_config);
$results['Vérification de version'] = ($version_data !== false);

// Test 2: Récupération d'informations
$info_data = test_info_retrieval($test_config);
$results['Récupération d\'informations'] = ($info_data !== false);

// Test 3: Accès au téléchargement
$download_url = null;
if ($info_data && isset($info_data['download_url'])) {
    $download_url = $info_data['download_url'];
}
$results['Accès au téléchargement'] = test_download_access($test_config, $download_url);

// Afficher le résumé
show_test_summary($results);
show_configuration_help();

echo "\nTest terminé.\n";
?>